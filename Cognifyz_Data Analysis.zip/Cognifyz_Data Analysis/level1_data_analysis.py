"""
Cognifyz Technologies - Data Analysis Internship
LEVEL 1 - Complete Solution
Tasks: Top Cuisines | City Analysis | Price Range Distribution | Online Delivery
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style("whitegrid")
plt.rcParams['figure.dpi'] = 110

df = pd.read_csv("Dataset .csv")

print("="*70)
print("LEVEL 1 - DATA ANALYSIS INTERNSHIP (COGNIFYZ TECHNOLOGIES)")
print("="*70)

# ---------------------------------------------------------------
# TASK 1: TOP CUISINES
# ---------------------------------------------------------------
print("\n" + "-"*70)
print("TASK 1: TOP CUISINES")
print("-"*70)

# Cuisines column has comma-separated values, split and explode
cuisine_series = df['Cuisines'].dropna().str.split(', ').explode()
cuisine_counts = cuisine_series.value_counts()

top3_cuisines = cuisine_counts.head(3)
print("\nTop 3 most common cuisines:")
print(top3_cuisines)

total_restaurants = len(df)
print(f"\nPercentage of restaurants serving each top cuisine (out of {total_restaurants} restaurants):")
for cuisine, count in top3_cuisines.items():
    pct = (count / total_restaurants) * 100
    print(f"  {cuisine}: {pct:.2f}%  ({count} restaurants)")

# Chart
plt.figure(figsize=(8, 5))
top10 = cuisine_counts.head(10)
sns.barplot(x=top10.values, y=top10.index, palette="viridis")
plt.title("Top 10 Most Common Cuisines")
plt.xlabel("Number of Restaurants")
plt.ylabel("Cuisine")
plt.tight_layout()
plt.savefig("outputs/L1_T1_top_cuisines.png")
plt.close()
print("Saved chart -> outputs/L1_T1_top_cuisines.png")

# ---------------------------------------------------------------
# TASK 2: CITY ANALYSIS
# ---------------------------------------------------------------
print("\n" + "-"*70)
print("TASK 2: CITY ANALYSIS")
print("-"*70)

city_counts = df['City'].value_counts()
city_with_most = city_counts.idxmax()
print(f"\nCity with highest number of restaurants: {city_with_most} ({city_counts.max()} restaurants)")

city_avg_rating = df.groupby('City')['Aggregate rating'].mean().sort_values(ascending=False)
print("\nAverage rating by city (top 10):")
print(city_avg_rating.head(10).round(2))

city_highest_rating = city_avg_rating.idxmax()
print(f"\nCity with highest average rating: {city_highest_rating} ({city_avg_rating.max():.2f})")

# Chart - top 10 cities by restaurant count
plt.figure(figsize=(8, 5))
top10_cities = city_counts.head(10)
sns.barplot(x=top10_cities.values, y=top10_cities.index, palette="mako")
plt.title("Top 10 Cities by Number of Restaurants")
plt.xlabel("Number of Restaurants")
plt.ylabel("City")
plt.tight_layout()
plt.savefig("outputs/L1_T2_city_restaurant_count.png")
plt.close()
print("Saved chart -> outputs/L1_T2_city_restaurant_count.png")

# ---------------------------------------------------------------
# TASK 3: PRICE RANGE DISTRIBUTION
# ---------------------------------------------------------------
print("\n" + "-"*70)
print("TASK 3: PRICE RANGE DISTRIBUTION")
print("-"*70)

price_counts = df['Price range'].value_counts().sort_index()
price_pct = (price_counts / total_restaurants * 100).round(2)

print("\nRestaurant count by price range:")
print(price_counts)
print("\nPercentage of restaurants in each price range:")
print(price_pct)

plt.figure(figsize=(7, 5))
sns.barplot(x=price_counts.index, y=price_counts.values, palette="rocket")
plt.title("Distribution of Price Ranges")
plt.xlabel("Price Range (1=Low, 4=High)")
plt.ylabel("Number of Restaurants")
plt.tight_layout()
plt.savefig("outputs/L1_T3_price_range_distribution.png")
plt.close()
print("Saved chart -> outputs/L1_T3_price_range_distribution.png")

# ---------------------------------------------------------------
# TASK 4: ONLINE DELIVERY
# ---------------------------------------------------------------
print("\n" + "-"*70)
print("TASK 4: ONLINE DELIVERY")
print("-"*70)

delivery_counts = df['Has Online delivery'].value_counts()
delivery_pct = (delivery_counts / total_restaurants * 100).round(2)
print("\nRestaurants offering online delivery:")
print(delivery_pct)

avg_rating_by_delivery = df.groupby('Has Online delivery')['Aggregate rating'].mean().round(2)
print("\nAverage rating: with vs without online delivery:")
print(avg_rating_by_delivery)

plt.figure(figsize=(6, 5))
sns.barplot(x=avg_rating_by_delivery.index, y=avg_rating_by_delivery.values, palette="crest")
plt.title("Average Rating: Online Delivery vs No Online Delivery")
plt.xlabel("Has Online Delivery")
plt.ylabel("Average Rating")
plt.tight_layout()
plt.savefig("outputs/L1_T4_online_delivery_rating.png")
plt.close()
print("Saved chart -> outputs/L1_T4_online_delivery_rating.png")

print("\n" + "="*70)
print("LEVEL 1 COMPLETE")
print("="*70)
