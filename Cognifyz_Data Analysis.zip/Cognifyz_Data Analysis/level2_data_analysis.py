"""
Cognifyz Technologies - Data Analysis Internship
LEVEL 2 - Complete Solution
Tasks: Restaurant Ratings | Cuisine Combination | Geographic Analysis | Restaurant Chains
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter

sns.set_style("whitegrid")
plt.rcParams['figure.dpi'] = 110

df = pd.read_csv("Dataset .csv")
total_restaurants = len(df)

print("="*70)
print("LEVEL 2 - DATA ANALYSIS INTERNSHIP (COGNIFYZ TECHNOLOGIES)")
print("="*70)

# ---------------------------------------------------------------
# TASK 1: RESTAURANT RATINGS
# ---------------------------------------------------------------
print("\n" + "-"*70)
print("TASK 1: RESTAURANT RATINGS")
print("-"*70)

# Bin ratings into ranges
bins = [0, 1, 2, 3, 4, 5]
labels = ["0-1", "1-2", "2-3", "3-4", "4-5"]
df['Rating Range'] = pd.cut(df['Aggregate rating'], bins=bins, labels=labels, include_lowest=True)

rating_range_counts = df['Rating Range'].value_counts().sort_index()
print("\nDistribution of aggregate ratings by range:")
print(rating_range_counts)

most_common_range = rating_range_counts.idxmax()
print(f"\nMost common rating range: {most_common_range} ({rating_range_counts.max()} restaurants)")

avg_votes = df['Votes'].mean()
print(f"\nAverage number of votes received by restaurants: {avg_votes:.2f}")

plt.figure(figsize=(7, 5))
sns.barplot(x=rating_range_counts.index.astype(str), y=rating_range_counts.values, palette="flare")
plt.title("Distribution of Aggregate Ratings")
plt.xlabel("Rating Range")
plt.ylabel("Number of Restaurants")
plt.tight_layout()
plt.savefig("outputs/L2_T1_rating_distribution.png")
plt.close()
print("Saved chart -> outputs/L2_T1_rating_distribution.png")

# ---------------------------------------------------------------
# TASK 2: CUISINE COMBINATION
# ---------------------------------------------------------------
print("\n" + "-"*70)
print("TASK 2: CUISINE COMBINATION")
print("-"*70)

combo_series = df['Cuisines'].dropna()
combo_counts = combo_series.value_counts()
top_combos = combo_counts.head(10)
print("\nTop 10 most common cuisine combinations:")
print(top_combos)

# Average rating per combination (only combos with enough restaurants for reliability)
combo_ratings = df.dropna(subset=['Cuisines']).groupby('Cuisines')['Aggregate rating'].agg(['mean', 'count'])
combo_ratings = combo_ratings[combo_ratings['count'] >= 10].sort_values('mean', ascending=False)
print("\nTop 10 cuisine combinations by average rating (min. 10 restaurants):")
print(combo_ratings.head(10).round(2))

plt.figure(figsize=(9, 5))
sns.barplot(x=top_combos.values, y=top_combos.index, palette="magma")
plt.title("Top 10 Most Common Cuisine Combinations")
plt.xlabel("Number of Restaurants")
plt.ylabel("Cuisine Combination")
plt.tight_layout()
plt.savefig("outputs/L2_T2_cuisine_combinations.png")
plt.close()
print("Saved chart -> outputs/L2_T2_cuisine_combinations.png")

# ---------------------------------------------------------------
# TASK 3: GEOGRAPHIC ANALYSIS
# ---------------------------------------------------------------
print("\n" + "-"*70)
print("TASK 3: GEOGRAPHIC ANALYSIS")
print("-"*70)

geo_df = df[(df['Longitude'] != 0) & (df['Latitude'] != 0)]
print(f"\nPlotting {len(geo_df)} restaurants with valid coordinates.")

plt.figure(figsize=(9, 6))
scatter = plt.scatter(geo_df['Longitude'], geo_df['Latitude'],
                       c=geo_df['Aggregate rating'], cmap='YlOrRd',
                       alpha=0.5, s=10)
plt.colorbar(scatter, label='Aggregate Rating')
plt.title("Geographic Distribution of Restaurants (colored by rating)")
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.tight_layout()
plt.savefig("outputs/L2_T3_geographic_distribution.png")
plt.close()
print("Saved chart -> outputs/L2_T3_geographic_distribution.png")

# Cluster insight: restaurants per city (proxy for geographic clustering)
cluster_insight = df['City'].value_counts().head(5)
print("\nTop 5 geographic clusters (by city -> restaurant count):")
print(cluster_insight)
print("\nObservation: Restaurants are heavily concentrated in a small number of")
print("metro cities (e.g. New Delhi), forming dense clusters, while most other")
print("cities have only a handful of listed restaurants — visible as a dense")
print("point cloud in the scatter plot around those metro coordinates.")

# ---------------------------------------------------------------
# TASK 4: RESTAURANT CHAINS
# ---------------------------------------------------------------
print("\n" + "-"*70)
print("TASK 4: RESTAURANT CHAINS")
print("-"*70)

name_counts = df['Restaurant Name'].value_counts()
chains = name_counts[name_counts > 1]
print(f"\nNumber of restaurant names appearing more than once (chains): {len(chains)}")
print("\nTop 10 largest restaurant chains (by number of outlets):")
print(chains.head(10))

chain_stats = df[df['Restaurant Name'].isin(chains.index)].groupby('Restaurant Name').agg(
    Outlets=('Restaurant Name', 'count'),
    Avg_Rating=('Aggregate rating', 'mean'),
    Total_Votes=('Votes', 'sum')
).sort_values('Outlets', ascending=False)
print("\nRatings and popularity of top 10 chains:")
print(chain_stats.head(10).round(2))

plt.figure(figsize=(8, 5))
top10_chains = chain_stats.head(10)
sns.barplot(x=top10_chains['Outlets'], y=top10_chains.index, palette="cubehelix")
plt.title("Top 10 Restaurant Chains by Number of Outlets")
plt.xlabel("Number of Outlets")
plt.ylabel("Restaurant Chain")
plt.tight_layout()
plt.savefig("outputs/L2_T4_restaurant_chains.png")
plt.close()
print("Saved chart -> outputs/L2_T4_restaurant_chains.png")

print("\n" + "="*70)
print("LEVEL 2 COMPLETE")
print("="*70)
